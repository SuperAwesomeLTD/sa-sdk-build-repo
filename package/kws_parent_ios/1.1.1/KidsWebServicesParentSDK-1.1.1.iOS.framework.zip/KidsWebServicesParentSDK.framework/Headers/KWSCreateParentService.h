
#import <UIKit/UIKit.h>
#import "KWSService.h"


typedef NS_ENUM(NSInteger, KWS_CREATE_PARENT_STATUS) {
    CREATED,
    DUPLICATE,
    INVALID_EMAIL,
    INVALID_PASSWORD,
    NETWORK_ERROR
};

typedef void (^didCreateParent)(KWS_CREATE_PARENT_STATUS status);

@interface KWSCreateParentService : KWSService

- (void) execute:(NSString*)email withPassword:(NSString*)password onDone:(didCreateParent)didCreateParent;

@end
