
#import <UIKit/UIKit.h>

// services
#import "KWSCreateParentService.h"
#import "KWSAuthService.h"
#import "KWSGetParentService.h"
#import "KWSUpdateParentService.h"

// models
#import "KWSLoggedUser.h"
#import "KWSMetadata.h"
#import "KWSParentUser.h"

@interface KWSParent : NSObject

// singleton func
+ (instancetype) sdk;

/**
 */
- (void) create:(NSString*) parentEmail
           with:(NSString*) password
            and:(didCreateParent) response;

- (void) login:(NSString*) parentEmail
          with:(NSString*) password
           and:(didAuthParent) response;

- (void) logout;

- (void) getParentData:(didGetParent) response;

- (void) update:(KWSParentUser*) parent
            and:(didUpdateParent) response;

- (KWSLoggedUser*) getLoggedUser;

- (NSString*) getVersion;

@end
