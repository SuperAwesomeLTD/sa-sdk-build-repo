
#import "KWSService.h"

@class KWSLoggedUser;

typedef void (^didAuthParentInternal)(KWSLoggedUser *loggedUser);
typedef void (^didAuthParent)(BOOL operationOK);

@interface KWSAuthService : KWSService

- (void) execute: (NSString*) email
    withPassword:(NSString*) password
          onDone: (didAuthParentInternal) didAuthParentInternal;



@end
