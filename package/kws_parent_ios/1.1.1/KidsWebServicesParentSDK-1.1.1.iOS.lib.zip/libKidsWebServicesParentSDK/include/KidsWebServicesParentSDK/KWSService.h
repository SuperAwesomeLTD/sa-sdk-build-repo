
#import <UIKit/UIKit.h>

#import "KWSLoggedUser.h"
#import "KWSMetadata.h"

typedef NS_ENUM(NSInteger, KWS_HTTP_METHOD) {
    GET,
    POST,
    PUT,
    PATCH
};

@protocol KWSServiceProtocol <NSObject>

- (NSString*) getEndpoint;
- (KWS_HTTP_METHOD) getMethod;
- (NSDictionary*) getQuery;
- (NSDictionary*) getHeader;
- (NSDictionary*) getBody;
- (BOOL) needsLoggedUser;
- (void) successWithStatus:(NSInteger)status andPayload:(NSString*)payload andSuccess:(BOOL) success;

@end

@interface KWSService : NSObject <KWSServiceProtocol> {
    NSString *kwsApiUrl;
    KWSLoggedUser *loggedUser;
}

- (void) execute;

@end
