
#import <UIKit/UIKit.h>

#if defined(__has_include)
#if __has_include(<SAJsonParser/SAJsonParser.h>)
#import <SAJsonParser/SAJsonParser.h>
#else
#import "SAJsonParser.h"
#endif
#endif

#if defined(__has_include)
#if __has_include(<SAJsonParser/SABaseObject.h>)
#import <SAJsonParser/SABaseObject.h>
#else
#import "SABaseObject.h"
#endif
#endif

@interface KWSParentUser : SABaseObject <SASerializationProtocol, SADeserializationProtocol>

@property (nonatomic, assign, readonly) NSInteger _id;
@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSString *firstName;
@property (nonatomic, strong) NSString *lastName;
@property (nonatomic, strong) NSString *dateOfBirth;
@property (nonatomic, strong) NSString *gender;
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *postalCode;
@property (nonatomic, strong) NSString *streetAddress;
@property (nonatomic, strong) NSString *country;
@property (nonatomic, strong, readonly) NSString *countryName;
@property (nonatomic, strong) NSString *language;
@property (nonatomic, strong, readonly) NSString *languageName;
@property (nonatomic, strong) NSString *stripeChargeId;
@property (nonatomic, assign) BOOL newsletterEnabled;
@property (nonatomic, assign) BOOL splashpageVisited;
@property (nonatomic, strong, readonly) NSString *createdAt;

- (NSDictionary*) updateDictionaryRepresentation;

@end
