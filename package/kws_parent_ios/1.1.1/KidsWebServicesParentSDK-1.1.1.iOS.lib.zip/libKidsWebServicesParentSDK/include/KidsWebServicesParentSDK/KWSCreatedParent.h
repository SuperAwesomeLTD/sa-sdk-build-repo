
#import <UIKit/UIKit.h>

#if defined(__has_include)
#if __has_include(<SAJsonParser/SAJsonParser.h>)
#import <SAJsonParser/SAJsonParser.h>
#else
#import "SAJsonParser.h"
#endif
#endif

#if defined(__has_include)
#if __has_include(<SAJsonParser/SABaseObject.h>)
#import <SAJsonParser/SABaseObject.h>
#else
#import "SABaseObject.h"
#endif
#endif

@interface KWSCreatedParent : SABaseObject <SASerializationProtocol, SADeserializationProtocol>

@property (nonatomic, assign, readonly) NSInteger _id;
@property (nonatomic, assign, readonly) NSInteger code;
@property (nonatomic, strong, readonly) NSDictionary *invalid;

- (BOOL) isEmailDuplicate;
- (BOOL) isEmailInvalid;
- (BOOL) isPasswordInvalid;

@end
