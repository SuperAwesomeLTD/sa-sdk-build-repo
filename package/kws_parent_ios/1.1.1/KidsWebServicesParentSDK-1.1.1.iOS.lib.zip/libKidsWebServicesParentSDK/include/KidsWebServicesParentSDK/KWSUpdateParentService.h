
#import "KWSService.h"

#import "KWSParentUser.h"

typedef void (^didUpdateParent)(BOOL operationOK);

@interface KWSUpdateParentService: KWSService

- (void) execute: (KWSParentUser*) updatedParentUser onDone:(didUpdateParent)didUpdateParent;

@end
