#import <UIKit/UIKit.h>

#if defined(__has_include)
#if __has_include(<SAJsonParser/SAJsonParser.h>)
#import <SAJsonParser/SAJsonParser.h>
#else
#import "SAJsonParser.h"
#endif
#endif

#if defined(__has_include)
#if __has_include(<SAJsonParser/SABaseObject.h>)
#import <SAJsonParser/SABaseObject.h>
#else
#import "SABaseObject.h"
#endif
#endif

@interface KWSMetadata : SABaseObject <SASerializationProtocol, SADeserializationProtocol, NSCoding>

@property (nonatomic, assign, readonly) NSInteger userId;
@property (nonatomic, strong, readonly) NSString *clientId;
@property (nonatomic, strong, readonly) NSString *scope;
@property (nonatomic, assign, readonly) NSInteger iat;
@property (nonatomic, assign, readonly) NSInteger exp;
@property (nonatomic, strong, readonly) NSString *iss;

@end
