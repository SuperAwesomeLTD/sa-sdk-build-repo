
#import "KWSService.h"

@class KWSLoggedUser;

typedef void (^KWSParentLoginUserInternalBlock)(KWSLoggedUser *loggedUser);
typedef void (^KWSParentLoginUserBlock)(BOOL operationOK);

@interface KWSAuthService : KWSService

- (void) execute: (NSString*) email
    withPassword:(NSString*) password
          onDone: (KWSParentLoginUserInternalBlock) response;



@end
