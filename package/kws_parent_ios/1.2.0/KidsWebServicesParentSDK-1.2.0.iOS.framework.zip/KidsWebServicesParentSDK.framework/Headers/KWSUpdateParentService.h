
#import "KWSService.h"

#import "KWSParentUser.h"

typedef void (^KWSParentUpdateUserBlock)(BOOL operationOK);

@interface KWSUpdateParentService: KWSService

- (void) execute: (KWSParentUser*) updatedParentUser
          onDone:(KWSParentUpdateUserBlock)didUpdateParent;

@end
