
#import <UIKit/UIKit.h>

// services
#import "KWSCreateParentService.h"
#import "KWSAuthService.h"
#import "KWSGetParentService.h"
#import "KWSUpdateParentService.h"

// models
#import "KWSLoggedUser.h"
#import "KWSMetadata.h"
#import "KWSParentUser.h"

@interface KWSParent : NSObject

// singleton func
+ (instancetype) sdk;

/**
 */
- (void) createUser:(NSString*) parentEmail
       withPassword:(NSString*) password
        andResponse:(KWSParentCreateUserBlock) response;

- (void) loginUser:(NSString*) parentEmail
      withPassword:(NSString*) password
       andResponse:(KWSParentLoginUserBlock) response;

- (void) logoutUser;

- (void) getUser:(KWSParentGetUserBlock) response;

- (void) updateUser:(KWSParentUser*) parent
       withResponse:(KWSParentUpdateUserBlock) response;

- (KWSLoggedUser*) getLoggedUser;

- (BOOL) isUserLogged;

- (NSString*) getVersion;

@end
