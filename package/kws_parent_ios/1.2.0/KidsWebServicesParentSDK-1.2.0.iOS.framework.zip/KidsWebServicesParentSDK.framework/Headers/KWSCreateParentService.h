
#import <UIKit/UIKit.h>
#import "KWSService.h"


typedef NS_ENUM(NSInteger, KWSParentCreateUserStatus) {
    KWSParent_CreateUser_Success            = 0,
    KWSParent_CreateUser_DuplicateUsername  = 1,
    KWSParent_CreateUser_InvalidEmail       = 2,
    KWSParent_CreateUser_InvalidPassword    = 3,
    KWSParent_CreateUser_NetworkError       = 4
};

typedef void (^KWSParentCreateUserBlock)(KWSParentCreateUserStatus status);

@interface KWSCreateParentService : KWSService

- (void) execute:(NSString*)email
    withPassword:(NSString*)password
          onDone:(KWSParentCreateUserBlock)response;

@end
