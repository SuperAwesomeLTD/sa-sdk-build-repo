
#import "KWSService.h"

@class KWSParentUser;


typedef void (^KWSParentGetUserBlock)(KWSParentUser *parent);

@interface KWSGetParentService : KWSService

- (void) execute:(KWSParentGetUserBlock)didGetParent;

@end
