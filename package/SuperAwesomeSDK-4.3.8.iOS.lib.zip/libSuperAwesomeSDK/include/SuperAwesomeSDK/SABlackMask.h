//
//  SABlackMask.h
//  Pods
//
//  Created by Gabriel Coman on 08/01/2016.
//
//

#import <UIKit/UIKit.h>

@interface SABlackMask : UIView
@end
