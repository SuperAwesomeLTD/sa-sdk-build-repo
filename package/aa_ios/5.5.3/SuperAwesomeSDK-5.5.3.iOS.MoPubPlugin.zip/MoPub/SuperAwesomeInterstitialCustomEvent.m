/**
 * @Copyright:   SuperAwesome Trading Limited 2017
 * @Author:      Gabriel Coman (gabriel.coman@superawesome.tv)
 */

#import "SuperAwesomeInterstitialCustomEvent.h"
#import "SuperAwesome.h"
#import "SuperAwesomeMoPub.h"

@interface SuperAwesomeInterstitialCustomEvent ()
@property (nonatomic, assign) NSInteger placementId;
@end

@implementation SuperAwesomeInterstitialCustomEvent

/**
 * Overridden MoPub method that requests a new interstitial.
 *
 * @param info a dictionary of extra information passed down from MoPub to the
 *             SDK that help with loading the ad
 */
- (void) requestInterstitialWithCustomEventInfo:(NSDictionary *)info {
    
    // variables received from the MoPub server
    id _Nullable placementIdObj = [info objectForKey:PLACEMENT_ID];
    id _Nullable isTestEnabledObj = [info objectForKey:TEST_ENABLED];
    id _Nullable isParentalGateEnabledObj = [info objectForKey:PARENTAL_GATE];
    id _Nullable lockOrientationObj = [info objectForKey:LOCK_ORIENTATION];
    id _Nullable orientationObj = [info objectForKey:ORIENTATION];
    
    NSInteger placementId = SA_DEFAULT_PLACEMENTID;
    BOOL isTestEnabled = SA_DEFAULT_TESTMODE;
    BOOL isParentalGateEnabled = SA_DEFAULT_PARENTALGATE;
    SAOrientation orientation = SA_DEFAULT_ORIENTATION;
    
    if (placementIdObj) {
        placementId = [placementIdObj integerValue];
    }
    if (isTestEnabledObj) {
        isTestEnabled = [isTestEnabledObj boolValue];
    }
    if (isParentalGateEnabledObj) {
        isParentalGateEnabled = [isParentalGateEnabledObj boolValue];
    }
    if (lockOrientationObj) {
        NSString *lockOrientationStr = (NSString*)lockOrientationObj;
        if (lockOrientationStr && [lockOrientationStr isEqualToString:@"PORTRAIT"]) {
            orientation = PORTRAIT;
        }
        if (lockOrientationStr && [lockOrientationStr isEqualToString:@"LANDSCAPE"]) {
            orientation = LANDSCAPE;
        }
    }
    if (orientationObj) {
        NSString *orientationStr = (NSString*)orientationObj;
        if (orientationStr && [orientationStr isEqualToString:@"PORTRAIT"]) {
            orientation = PORTRAIT;
        }
        if (orientationStr && [orientationStr isEqualToString:@"LANDSCAPE"]) {
            orientation = LANDSCAPE;
        }
    }
    
    // get a weak self reference
    __weak typeof (self) weakSelf = self;
    
    // start the loader
    [SAInterstitialAd setConfigurationProduction];
    [SAInterstitialAd setTestMode:isTestEnabled];
    [SAInterstitialAd setParentalGate:isParentalGateEnabled];
    [SAInterstitialAd setOrientation:orientation];
    
    [SAInterstitialAd setCallback:^(NSInteger placementId, SAEvent event) {
        switch (event) {
            case adLoaded: {
                [weakSelf.delegate interstitialCustomEvent:weakSelf didLoadAd:[SAInterstitialAd self]];
                break;
            }
            case adAlreadyLoaded:{
                // do nothing
                break;
            }
            case adFailedToLoad: {
                [weakSelf.delegate interstitialCustomEvent:weakSelf
                                  didFailToLoadAdWithError:[weakSelf createErrorWith:ERROR_LOAD_TITLE(@"Interstitial Ad", placementId)
                                                                           andReason:ERROR_LOAD_MESSAGE
                                                                       andSuggestion:ERROR_LOAD_SUGGESTION]];
                break;
            }
            case adShown: {
                [weakSelf.delegate interstitialCustomEventDidAppear:weakSelf];
                break;
            }
            case adFailedToShow: {
                [weakSelf.delegate interstitialCustomEvent:weakSelf
                                  didFailToLoadAdWithError:[weakSelf createErrorWith:ERROR_SHOW_TITLE(@"Interstitial Ad", 0)
                                                                           andReason:ERROR_SHOW_MESSAGE
                                                                       andSuggestion:ERROR_SHOW_SUGGESTION]];
                break;
            }
            case adClicked: {
                [weakSelf.delegate interstitialCustomEventDidReceiveTapEvent:weakSelf];
                [weakSelf.delegate interstitialCustomEventWillLeaveApplication:weakSelf];
                break;
            }
            case adEnded: {
                // do nothing
                break;
            }
            case adClosed: {
                [weakSelf.delegate interstitialCustomEventWillDisappear:weakSelf];
                [weakSelf.delegate interstitialCustomEventDidDisappear:weakSelf];
                break;
            }
        }
    }];
    
    // load
    [SAInterstitialAd load:_placementId];
}

/**
 * Overridden MoPub method that actually displays an interstitial ad.
 *
 * @param rootViewController the view controller from which the ad will spring
 */
- (void) showInterstitialFromRootViewController:(UIViewController *)rootViewController {
    [SAInterstitialAd play:_placementId
                    fromVC:rootViewController];
    [self.delegate interstitialCustomEventWillAppear:self];
}

/**
 * MoPub method that creates a new error obkect
 *
 * @param description   the description text of the error
 * @param reason        a reason for why it might have happened
 * @param suggestion    a suggestion of how to fix it
 */
- (NSError*) createErrorWith:(NSString*) description
                   andReason:(NSString*) reason
               andSuggestion:(NSString*) suggestion {
    
    NSDictionary *userInfo = @{
                               NSLocalizedDescriptionKey: NSLocalizedString(description, nil),
                               NSLocalizedFailureReasonErrorKey: NSLocalizedString(reason, nil),
                               NSLocalizedRecoverySuggestionErrorKey: NSLocalizedString(suggestion, nil)
                               };
    
    return [NSError errorWithDomain:ERROR_DOMAIN code:ERROR_CODE userInfo:userInfo];
}

@end
