//
//  SABumperImageUtils.h
//  Pods
//
//  Created by Gabriel Coman on 07/08/2017.
//
//

#import <UIKit/UIKit.h>

@interface SABumperImageUtils : NSObject
+ (UIImage*) backgroundImage;
+ (UIImage*) defaultLogo;
+ (UIImage*) poweredByImage;
@end
