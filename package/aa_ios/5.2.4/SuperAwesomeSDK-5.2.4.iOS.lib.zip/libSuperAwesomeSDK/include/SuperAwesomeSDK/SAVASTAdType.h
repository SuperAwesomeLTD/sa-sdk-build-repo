//
//  SAVASTAdType.h
//  Pods
//
//  Created by Gabriel Coman on 27/09/2016.
//
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, SAVASTAdType) {
    InLine = 0,
    Wrapper = 1
};
