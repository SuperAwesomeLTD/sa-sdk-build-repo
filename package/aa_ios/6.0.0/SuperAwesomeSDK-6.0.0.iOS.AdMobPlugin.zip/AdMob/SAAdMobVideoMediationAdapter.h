#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface SAAdMobVideoMediationAdapter : NSObject <GADMRewardBasedVideoAdNetworkAdapter>
@end
