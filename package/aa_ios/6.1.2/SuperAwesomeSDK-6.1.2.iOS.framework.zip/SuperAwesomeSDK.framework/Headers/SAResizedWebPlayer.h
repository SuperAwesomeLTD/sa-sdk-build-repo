#import "SAExpandedWebPlayer.h"
@class SAWebPlayer;

@interface SAResizedWebPlayer : SAExpandedWebPlayer
@property (nonatomic, weak) SAWebPlayer *parent;
@end
