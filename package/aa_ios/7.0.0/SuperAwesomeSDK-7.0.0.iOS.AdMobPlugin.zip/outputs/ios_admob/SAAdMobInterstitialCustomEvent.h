#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface SAAdMobInterstitialCustomEvent : NSObject <GADCustomEventInterstitial>
@end
