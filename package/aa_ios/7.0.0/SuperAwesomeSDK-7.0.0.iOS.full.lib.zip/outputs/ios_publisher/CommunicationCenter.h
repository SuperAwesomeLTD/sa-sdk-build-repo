//
//  CommunicationCenter.h
//  SAGDPRKisMinor
//
//  Created by Guilherme Mota on 27/04/2018.
//

FOUNDATION_EXPORT NSString *const isMinorURL;
