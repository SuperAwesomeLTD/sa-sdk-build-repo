#import <UIKit/UIKit.h>
#import "SAMoatModule.h"

@interface SAMoatModule (Moat)
@end
