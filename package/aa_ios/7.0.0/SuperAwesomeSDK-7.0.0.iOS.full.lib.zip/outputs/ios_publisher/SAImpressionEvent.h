/**
 * @Copyright:   SuperAwesome Trading Limited 2017
 * @Author:      Gabriel Coman (gabriel.coman@superawesome.tv)
 */

#import "SAServerEvent.h"

@interface SAImpressionEvent : SAServerEvent
@end
