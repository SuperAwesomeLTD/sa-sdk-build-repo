#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface SAAdMobBannerCustomEvent : NSObject<GADCustomEventBanner>
@end
