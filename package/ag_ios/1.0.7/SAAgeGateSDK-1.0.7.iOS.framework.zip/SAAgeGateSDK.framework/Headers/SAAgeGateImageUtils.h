//
//  SAAgeGateImageUtils.h
//  Pods
//
//  Created by Gabriel Coman on 10/08/2017.
//
//

#import <UIKit/UIKit.h>

@interface SAAgeGateImageUtils : NSObject
+ (UIImage*) backgroundImage;
+ (UIImage*) defaultLogo;
+ (UIImage*) poweredByImage;
@end
