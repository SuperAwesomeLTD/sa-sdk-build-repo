//
//  SACapper.h
//  Pods
//
//  Created by Gabriel Coman on 16/02/2016.
//
//

#import <Foundation/Foundation.h>

@interface SACapper : NSObject

/**
 *  Get the Dau ID
 */
- (NSUInteger) getDauId;

@end
