//
//  SACampaignType.h
//  Pods
//
//  Created by Gabriel Coman on 19/10/2016.
//
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, SACampaignType) {
    cpm = 0,
    cpi = 1
};
