//
//  SADefines.h
//  Pods
//
//  Created by Gabriel Coman on 15/09/2016.
//
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, SAOrientation) {
    ANY = 0,
    PORTRAIT = 1,
    LANDSCAPE = 2
};