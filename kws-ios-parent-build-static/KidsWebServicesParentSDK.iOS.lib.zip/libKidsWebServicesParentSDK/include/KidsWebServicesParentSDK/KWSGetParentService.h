
#import "KWSService.h"

@class KWSParentUser;


typedef void (^didGetParent)(KWSParentUser *parent);

@interface KWSGetParentService : KWSService

- (void) execute:(didGetParent)didGetParent;

@end
