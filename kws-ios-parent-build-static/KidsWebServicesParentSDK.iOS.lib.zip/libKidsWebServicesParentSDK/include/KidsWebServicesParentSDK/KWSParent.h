
#import <UIKit/UIKit.h>

// services
#import "KWSCreateParentService.h"
#import "KWSAuthService.h"
#import "KWSGetParentService.h"
#import "KWSUpdateParentService.h"

// models
#import "KWSLoggedUser.h"
#import "KWSMetadata.h"
#import "KWSParentUser.h"

@interface KWSParent : NSObject

// singleton func
+ (instancetype) sdk;

// the current in-memory logged user
@property (nonatomic, strong) KWSLoggedUser *loggedUser;

/**
 */
- (void) createParentAccountFor:(NSString*)email
                   withPassword:(NSString*)password
                         onDone:(didCreateParent)didCreateParent;

- (void) loginParentAccountFor:(NSString*)email
                  withPassword:(NSString*)password
                        onDone:(didAuthParent)didAuthParent;
- (void) logout;

- (void) getParentData:(didGetParent) didGetParent;

- (void) updateParentWith:(KWSParentUser*)parentToUpdate
                   onDone:(didUpdateParent)didUpdateParent;


@end
