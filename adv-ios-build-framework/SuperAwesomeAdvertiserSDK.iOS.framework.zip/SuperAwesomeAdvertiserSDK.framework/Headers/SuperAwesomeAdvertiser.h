//
//  SuperAwesomeAdvertiser.h
//  Pods
//
//  Created by Gabriel Coman on 27/07/2017.
//
//

#ifndef SuperAwesomeAdvertiser_h
#define SuperAwesomeAdvertiser_h

#import "SAVerifyInstall.h"

#endif /* SuperAwesomeAdvertiser_h */
