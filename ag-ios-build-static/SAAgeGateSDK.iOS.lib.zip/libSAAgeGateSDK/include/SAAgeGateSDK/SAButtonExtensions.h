//
//  SAButtonExtensions.h
//  Pods
//
//  Created by Gabriel Coman on 10/08/2017.
//
//

#import <UIKit/UIKit.h>

@interface UIButton (SAButton)

- (void) lightButton;
- (void) darkButton;

@end
