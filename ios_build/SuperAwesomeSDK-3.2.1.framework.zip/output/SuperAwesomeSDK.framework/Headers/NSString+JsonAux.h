//
//  NSString+Aux.h
//  Pods
//
//  Created by Gabriel Coman on 26/04/2016.
//
//

#import <Foundation/Foundation.h>

@interface NSString (JsonAux)

- (NSString*) cleanFirstUnderscore;
- (NSString*) joinStringWithUnderscores;

@end
