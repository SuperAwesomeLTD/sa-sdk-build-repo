//
//  SAURLClicker.h
//  Pods
//
//  Created by Gabriel Coman on 17/12/2015.
//
//

#import <UIKit/UIKit.h>

//
// Class definition
@interface SAURLClicker : UIButton
@property (nonatomic, assign) BOOL shouldShowSmallClickButton;
@end
