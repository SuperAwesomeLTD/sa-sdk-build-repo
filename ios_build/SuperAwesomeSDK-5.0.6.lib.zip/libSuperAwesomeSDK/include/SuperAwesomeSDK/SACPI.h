//
//  SACPI.h
//  Pods
//
//  Created by Gabriel Coman on 25/08/2016.
//
//

#import <Foundation/Foundation.h>

@interface SACPI : NSObject

/**
 *  Send CPI event
 */
- (void) sendCPIEvent;

@end
