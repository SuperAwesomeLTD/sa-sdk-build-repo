//
//  SACronograph.h
//  TestVASTParser
//
//  Created by Gabriel Coman on 15/12/2015.
//  Copyright © 2015 Gabriel Coman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SACronograph : UIView

// custom function
- (void) setTime:(NSInteger)remaining;

@end
